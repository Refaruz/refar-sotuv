# REFAR — Sotuvchi lid formasi · O'rnatish yo'riqnomasi

Bu forma faqat **kvartira** sotuvchilarni va faqat **Toshkent shahar / Farg'ona shahar** hududini o'tkazadi. Nomos murojaatlar chiroyli tushuntirilib, Instagram/Telegram sahifalarga yo'naltiriladi. Toza lidlar avtomatik **amoCRM** + **Telegram**'ga tushadi.

Manzil: `https://refar-sotuv.vercel.app/`

---

## 1. Fayllar tuzilishi

Loyiha papkasi shunday bo'lishi kerak:

```
refar-form/
├── index.html          ← forma (frontend)
└── api/
    └── lead.js         ← server funksiyasi (amoCRM + Telegram)
```

`api/` papkasi majburiy — Vercel undagi fayllarni avtomatik server funksiyasiga aylantiradi (`/api/lead` manzili).

---

## 2. Vercel'ga joylash

### A variant — GitHub orqali (tavsiya etiladi)
1. GitHub'da yangi repozitoriy oching, `index.html` va `api/lead.js` ni yuklang.
2. https://vercel.com → **Add New → Project** → repozitoriyni tanlang.
3. Framework Preset: **Other** (o'zgartirish shart emas). **Deploy** bosing.
4. Manzil loyiha nomidan avtomatik kelib chiqadi. O'zgartirish uchun: Project → **Settings → General → Project Name** (masalan `refar-sotuv`). `.vercel.app` uchun "Add Domain" ishlatilmaydi.

### B variant — CLI orqali
```bash
npm i -g vercel
cd refar-form
vercel            # birinchi marta — loyihani bog'laydi
vercel --prod     # produkvariantga chiqarish
```

---

## 3. Environment Variables (maxfiy kalitlar)

Vercel → Project → **Settings → Environment Variables**. Har birini qo'shib, so'ng **qayta Deploy** qiling (o'zgarishlar shundagina kuchga kiradi).

| Nomi | Nima | Majburiymi |
|------|------|-----------|
| `AMO_SUBDOMAIN` | amoCRM subdomeni. `refar.amocrm.ru` bo'lsa → `refar` | ha (amoCRM uchun) |
| `AMO_ACCESS_TOKEN` | Uzoq muddatli (long-lived) token | ha |
| `AMO_PIPELINE_ID` | Voronka ID (qaysi voronkaga tushsin) | ixtiyoriy |
| `AMO_STATUS_ID` | Boshlang'ich bosqich ID | ixtiyoriy |
| `TG_BOT_TOKEN` | Telegram bot tokeni (@BotFather) | ixtiyoriy* |
| `TG_CHAT_TOSH` | Toshkent arizalari boradigan guruh/chat ID | ixtiyoriy* |
| `TG_CHAT_FARG` | Farg'ona arizalari boradigan guruh/chat ID | ixtiyoriy* |
| `TG_CHAT_ID` | Umumiy fallback (shahar aniqlanmasa) | ixtiyoriy |

\* amoCRM'siz ham faqat Telegram ishlashi mumkin — bittasi yetadi, ikkalasi ham bo'lsa yaxshi.

---

## 4. amoCRM ulash (long-lived token)

1. amoCRM → **Настройки → Интеграции**.
2. **Создать интеграцию → Внешняя (приватная) интеграция**.
3. Nom bering (masalan, "REFAR forma"), huquqlarga **CRM'ga to'liq kirish** bering, saqlang.
4. Yaratilgan integratsiyani oching → **Ключи и доступы** bo'limi.
5. **Долгосрочный токен (long-lived access token)** ni chiqaring va nusxa oling → bu `AMO_ACCESS_TOKEN`.
6. `AMO_SUBDOMAIN` — akkaunt manzili (`refar.amocrm.ru` → `refar`).

**Voronka ID (`AMO_PIPELINE_ID`)** ni topish: amoCRM'da kerakli voronkani ochsangiz, URL'da `pipeline_id=...` ko'rinadi. Qo'ymasangiz — lid asosiy voronkaga tushadi.

Ishlash mantig'i: forma `/api/v4/leads/complex` orqali **lead + contact** yaratadi, telefon kontaktga yoziladi, so'ng barcha tafsilotlar (tuman, xonalar, narx, UTM) **izoh (примечание)** sifatida qo'shiladi. Teglar: shahar, `kvartira`, UTM manbasi.

> Eslatma: token muddati tugasa (amoCRM belgilaydi), yangisini chiqarib `AMO_ACCESS_TOKEN` ni yangilang.

---

## 5. Telegram bildirishnoma (shahar bo'yicha)

Toshkent arizasi Toshkent guruhiga, Farg'ona arizasi Farg'ona guruhiga tushadi. Bitta bot ikkalasiga ham yozadi.

1. @BotFather → `/newbot` → tokenni oling → `TG_BOT_TOKEN`.
2. Telegram'da 2 ta guruh oching: "REFAR — Toshkent arizalar" va "REFAR — Farg'ona arizalar" (yoki mavjud shahar guruhlaringiz).
3. REFAR botini har ikkala guruhga qo'shing va **admin** qiling.
4. Har bir guruhning ID'sini oling: guruhga vaqtincha `@getmyid_bot` (yoki `@RawDataBot`) ni qo'shing — u guruh ID'sini yozadi (manfiy son, odatda `-100...` bilan boshlanadi). Toshkent va Farg'ona guruhlari ID'sini alohida ko'chirib oling, so'ng yordamchi botni guruhdan chiqarib yuboring.
5. Vercel Env'ga qo'shing: `TG_BOT_TOKEN`, `TG_CHAT_TOSH` (Toshkent guruh ID), `TG_CHAT_FARG` (Farg'ona guruh ID). Qayta Deploy qiling.

> Lichkaga (shaxsiy) xabar kelishini istasangiz: operator avval REFAR botini ochib **Start** bosishi shart (aks holda bot unga yoza olmaydi), so'ng `@userinfobot` orqali o'z ID'sini olib, uni `TG_CHAT_TOSH`/`TG_CHAT_FARG` ga qo'yasiz. Guruh usuli osonroq va ishonchliroq.

Har yangi arizada tegishli guruhga: shahar, ism, telefon, tuman, xonalar, narx va UTM manbasi tushadi.

---

## 6. Tracking (targetolog uchun) — Meta Pixel + Yandex Metrika

`index.html` ichidagi `CONFIG.track` blokiga ID'larni qo'ying:

```js
track: {
  metaPixelId: "1234567890",   // Meta (Instagram/Facebook) Pixel ID
  yandexMetrikaId: "98765432"  // Yandex Metrika counter ID
}
```

- ID qo'yilsa — sahifa ochilganda **PageView**, ariza yuborilganda **Lead** (Pixel) va **reachGoal("lead")** (Metrika) avtomatik yuboriladi.
- Yandex Metrika'da **Webvisor** yoqilgan — targetolog har bir tashrifni video ko'rinishida ko'radi.
- Bo'sh qoldirilsa — hech narsa yuklanmaydi (forma baribir ishlaydi).

**Konversiyani sozlash:**
- Meta Ads Manager → Events Manager'da Pixel'ni ko'ring, "Lead" hodisasini konversiya sifatida tanlang.
- Yandex Metrika → **Цели → reachGoal** → identifikator: `lead`.

---

## 7. Targetologga nima berish kerak

1. **Havola:** `https://refar-sotuv.vercel.app/` — lekin UTM shablon bilan (pastda).
2. **Pixel / Metrika:** o'z ID'larini `CONFIG.track` ga qo'yishi uchun ruxsat, yoki siz qo'yib, unga Events Manager/Metrika'ga kirish bering.
3. **UTM shablon** (Meta Ads uchun avtomatik parametrlar):

```
https://refar-sotuv.vercel.app/?utm_source=instagram&utm_medium=cpc&utm_campaign={{campaign.name}}&utm_content={{adset.name}}&utm_term={{ad.name}}
```

Bu UTM'lar formadan amoCRM izohiga va Telegram xabariga tushadi — qaysi reklama qaysi lidni keltirganini aniq ko'rasiz. Targetolog reklamani UTM bo'yicha optimizatsiya qiladi.

---

## 8. amoCRM voronka sozlamasi (tavsiya)

Toza lidlar tushgach, ular o'zi yopilmaydi — voronka kerak. Minimal bosqichlar:

1. **Yangi ariza** → SLA: 15 daqiqada qo'ng'iroq (Digital Pipeline avtomatik vazifa qo'yadi).
2. **Bog'lanildi / ko'rikka yozildi**
3. **Mutaxassis chiqdi (syomka)**
4. **Reklamada / xaridorlar bilan**
5. **Bitim (notarius)** → yopildi.

Digital Pipeline'da "Yangi ariza" bosqichiga o'tганда avtomatik: mas'ul agentga vazifa + (xohlasangiz) mijozga WhatsApp/Telegram salom xabari. Shu bilan 5 daqiqalik javob qoidasi bajariladi.

---

## 9. Test qilish

1. Deploy tugagach `https://refar-sotuv.vercel.app/` ni oching.
2. **Kvartira → Toshkent shahar → ma'lumot to'ldirish → yuborish**: amoCRM'da yangi lead + Telegram xabari chiqishi kerak.
3. **Hovli** yoki **Boshqa shahar** tanlang: otkaz + ijtimoiy sahifalar chiqishi kerak (amoCRM'ga tushmaydi — bu to'g'ri).
4. UTM'ni tekshirish: `...vercel.app/?utm_source=test&utm_campaign=sinov` bilan oching, ariza qoldiring — amoCRM izohида `test / sinov` ko'rinadi.
5. Muvaffaqiyat ekranida shahar bo'yicha to'g'ri operator chiqishini tekshiring: Toshkent → +998 88 055 51 11 / @refar_toshkent_operator; Farg'ona → +998 97 415 51 11 / @refar_call.

---

## Muammolar

- **amoCRM'ga tushmayapti:** `AMO_SUBDOMAIN`/`AMO_ACCESS_TOKEN` to'g'rimi, token muddati tugamaganmi, Env qo'shgach qayta Deploy qildingizmi? Vercel → **Deployments → Functions → Logs** dan xatoni ko'ring.
- **Telegram jim:** bot guruhda adminmi, `TG_CHAT_ID` to'g'rimi (guruh uchun manfiy son)?
- **Forma yuboradi-yu server javob bermaydi:** preview yoki Env yo'q — ariza baribir ko'rsatiladi, ma'lumot brauzer konsoliga yoziladi. Env qo'yib qayta Deploy qiling.
